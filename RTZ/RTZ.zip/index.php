<?php include("templateHeader.php");?>
<title>Race to Zero</title>
<link rel="stylesheet" href="css/index.css">
<link rel="stylesheet" href="css/game.css">
<script src="js/ObjectDefinitions.js"></script>
<script src="js/engine.js"></script>
<?php include("templateNav.php");?>
		
<div id="content">
	<div class='contentactual'>
	</div>
</div>

<?php include("templateFooter.php");?>