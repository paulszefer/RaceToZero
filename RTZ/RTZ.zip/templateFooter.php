<!-- This file provides a footer for every page on the website. -->
		<div id='footer'>
			<div class='footercontent'>
				<p>Copyright whatever</p>
			</div>
		</div>
	</body>
</html>