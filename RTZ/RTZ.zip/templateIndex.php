<!-- This file compiles the other template files. All pages should look something like 
this. -->
<?php include("templateHeader.php");?>
<!--insert page specific js css here-->
<title> Template page title </title>
<?php include ("templateNav.php"); ?>
		
<div id='content'>
	<div class='contentactual'>
		<h1>Huehue</h1>
		<br>
		<p>hueheuhue</p>
	</div>
</div>

<?php include ("templateFooter.php");?>